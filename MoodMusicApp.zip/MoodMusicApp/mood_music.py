import tkinter as tk
import os
import subprocess

# Get folder where audio and .py file is saved
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Define moods and correspond to audios
moods = [
    {"name": "Happy", "file": "happy.wav", "color": "yellow"},
    {"name": "Sad", "file": "sad.wav", "color": "lightblue"},
    {"name": "Calm", "file": "calm.wav", "color": "lightgreen"}
]

# Keep track of current process
current_process = None

#Functions
def play_track(file):
    global current_process
    stop_music()  # stop any existing song
    path = os.path.join(BASE_DIR, file)
    current_process = subprocess.Popen(["afplay", path])

def mood_action(mood):
    root.configure(bg=mood["color"])
    play_track(mood["file"])

def stop_music():
    global current_process
    if current_process:
        current_process.terminate()
        current_process = None

def quit_app():
    stop_music()
    root.destroy()

# GUI setup
root = tk.Tk()
root.title("Mood Music Selector")
root.geometry("400x300")
root.config(bg="white")

label = tk.Label(root, text="Select your mood:", font=("Arial", 16), bg="white")
label.pack(pady=20)

for mood in moods:
    tk.Button(root, text=mood["name"], width=10, bg=mood["color"],
              command=lambda m=mood: mood_action(m)).pack(pady=5)

tk.Button(root, text="Stop Music", width=10, bg="orange", command=stop_music).pack(pady=10)
tk.Button(root, text="Quit", width=10, bg="red", command=quit_app).pack(pady=10)

root.mainloop()





